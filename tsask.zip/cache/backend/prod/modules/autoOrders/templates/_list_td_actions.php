<td>
  <ul class="sf_admin_td_actions">
    <li class="sf_admin_action_view">
      <?php echo link_to(__('View', array(), 'messages'), 'orders/view?id='.$sa_orders->getId(), array()) ?>
    </li>
    <?php echo $helper->linkToDelete($sa_orders, array(  'params' =>   array(  ),  'confirm' => 'Are you sure?',  'class_suffix' => 'delete',  'label' => 'Delete',)) ?>
  </ul>
</td>
