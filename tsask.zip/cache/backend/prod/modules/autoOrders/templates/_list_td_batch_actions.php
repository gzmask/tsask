<td>
  <input type="checkbox" name="ids[]" value="<?php echo $sa_orders->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
