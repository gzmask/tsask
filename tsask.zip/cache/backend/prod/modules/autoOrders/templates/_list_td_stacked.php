<td colspan="3">
  <?php echo __('%%id%% - %%created_at%% - %%updated_at%%', array('%%id%%' => link_to($sa_orders->getId(), 'sa_orders_edit', $sa_orders), '%%created_at%%' => false !== strtotime($sa_orders->getCreatedAt()) ? format_date($sa_orders->getCreatedAt(), "f") : '&nbsp;', '%%updated_at%%' => false !== strtotime($sa_orders->getUpdatedAt()) ? format_date($sa_orders->getUpdatedAt(), "f") : '&nbsp;'), 'messages') ?>
</td>
