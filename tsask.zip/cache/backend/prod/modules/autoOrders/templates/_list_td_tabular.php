<td class="sf_admin_text sf_admin_list_td_id">
  <?php echo link_to($sa_orders->getId(), 'sa_orders_edit', $sa_orders) ?>
</td>
<td class="sf_admin_date sf_admin_list_td_created_at">
  <?php echo false !== strtotime($sa_orders->getCreatedAt()) ? format_date($sa_orders->getCreatedAt(), "f") : '&nbsp;' ?>
</td>
<td class="sf_admin_date sf_admin_list_td_updated_at">
  <?php echo false !== strtotime($sa_orders->getUpdatedAt()) ? format_date($sa_orders->getUpdatedAt(), "f") : '&nbsp;' ?>
</td>
