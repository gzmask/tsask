<?php use_helper('I18N', 'Date') ?>
<?php include_partial('forms/assets') ?>
<?php include_partial('forms/flashes') ?>
<dl class="txtcont">
  <?php echo form_tag_for($form, '@sa_forms') ?>
<dt>
<div class="ltit"><strong><?php echo __('New Forms', array(), 'messages') ?></strong></div>
<div class="rbtns">
    <?php include_partial('forms/form_actions', array('sa_forms' => $sa_forms, 'form' => $form, 'configuration' => $configuration, 'helper' => $helper)) ?></div>
<div class="clear"></div>
</dt>
<dd>
<div class="forms_cont">

<div class="fc_tit">
    <?php include_partial('forms/form_header', array('sa_forms' => $sa_forms, 'form' => $form, 'configuration' => $configuration)) ?>
</div>

<div class="fc_con userbuil_box">
    <?php include_partial('forms/form', array('sa_forms' => $sa_forms, 'form' => $form, 'configuration' => $configuration, 'helper' => $helper)) ?>
<!--<table width="100%" border="0" cellspacing="0" cellpadding="0" class="ub_tab">
  <tr>
    <th width="25%">
      <input name="" type="text" class="intxt" value="" /><br />
<span class="fonti">Username</span>
    </th>
    <td width="25%"><input name="input" type="text" class="intxt" value="" />
      <br />
     <span class="fonti"> Email</span></td>
    <td width="25%"><input name="input2" type="text" class="intxt" value="" />
      <br />
      <span class="fonti">First Name</span></td>
    <td>
      <input name="input3" type="text" class="intxt" value="" />
      <br />
      <span class="fonti">Last Name</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input name="input4" type="text" class="intxt" value="" />
      <br />
      <span class="fonti">Password</span></td>
    <td><span class="fonti fontc"><img src="../images/icon_ts.jpg" />Password must be at least 8 characters</span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input name="input5" type="text" class="intxt" value="" />
      <br />
      <span class="fonti">Confirm Password</span></td>
    <td>&nbsp;</td>
  </tr>
</table>-->
</div>

</div>
</dd>
  </form>
</dl>
