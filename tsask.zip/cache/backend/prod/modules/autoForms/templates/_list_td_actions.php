<td>
  <ul class="sf_admin_td_actions">
    <li class="sf_admin_action_view">
      <?php echo link_to(__('View', array(), 'messages'), 'forms/preview?id='.$sa_forms->getId(), array()) ?>
    </li>
    <?php echo $helper->linkToDelete($sa_forms, array(  'params' =>   array(  ),  'confirm' => 'Are you sure?',  'class_suffix' => 'delete',  'label' => 'Delete',)) ?>
    <?php echo $helper->linkToEdit($sa_forms, array(  'params' =>   array(  ),  'class_suffix' => 'edit',  'label' => 'Edit',)) ?>
  </ul>
</td>
