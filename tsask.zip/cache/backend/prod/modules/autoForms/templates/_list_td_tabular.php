<td class="sf_admin_text sf_admin_list_td_id">
  <?php echo link_to($sa_forms->getId(), 'sa_forms_edit', $sa_forms) ?>
</td>
<td class="sf_admin_text sf_admin_list_td_form_name">
  <?php echo $sa_forms->getFormName() ?>
</td>
<td class="sf_admin_date sf_admin_list_td_created_at">
  <?php echo false !== strtotime($sa_forms->getCreatedAt()) ? format_date($sa_forms->getCreatedAt(), "f") : '&nbsp;' ?>
</td>
<td class="sf_admin_date sf_admin_list_td_updated_at">
  <?php echo false !== strtotime($sa_forms->getUpdatedAt()) ? format_date($sa_forms->getUpdatedAt(), "f") : '&nbsp;' ?>
</td>
