<td colspan="4">
  <?php echo __('%%id%% - %%form_name%% - %%created_at%% - %%updated_at%%', array('%%id%%' => link_to($sa_forms->getId(), 'sa_forms_edit', $sa_forms), '%%form_name%%' => $sa_forms->getFormName(), '%%created_at%%' => false !== strtotime($sa_forms->getCreatedAt()) ? format_date($sa_forms->getCreatedAt(), "f") : '&nbsp;', '%%updated_at%%' => false !== strtotime($sa_forms->getUpdatedAt()) ? format_date($sa_forms->getUpdatedAt(), "f") : '&nbsp;'), 'messages') ?>
</td>
