<td colspan="4">
  <?php echo __('%%username%% - %%email_address%% - %%last_name%% - %%first_name%%', array('%%username%%' => link_to($sf_guard_user->getUsername(), 'sf_guard_user_edit', $sf_guard_user), '%%email_address%%' => $sf_guard_user->getEmailAddress(), '%%last_name%%' => $sf_guard_user->getLastName(), '%%first_name%%' => $sf_guard_user->getFirstName()), 'messages') ?>
</td>
