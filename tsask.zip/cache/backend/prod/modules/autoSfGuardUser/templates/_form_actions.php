<ul class="sf_admin_actions">
<?php if ($form->isNew()): ?>
  <?php echo $helper->linkToSave($form->getObject(), array(  'label' => 'SAVE',  'params' =>   array(  ),  'class_suffix' => 'save',)) ?>
  <?php echo $helper->linkToList(array(  'label' => 'CANCEL',  'params' =>   array(  ),  'class_suffix' => 'list',)) ?>
<?php else: ?>
  <?php echo $helper->linkToSave($form->getObject(), array(  'label' => 'SAVE',  'params' =>   array(  ),  'class_suffix' => 'save',)) ?>
  <?php echo $helper->linkToList(array(  'label' => 'CANCEL',  'params' =>   array(  ),  'class_suffix' => 'list',)) ?>
<?php endif; ?>
</ul>
