<li class="sf_admin_action_delete">
  <?php echo link_to(__('X', array(), 'messages'), 'sfGuardUser/List_delete', array()) ?>
</li>
