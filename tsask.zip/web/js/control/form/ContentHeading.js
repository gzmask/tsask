function formHeading(obj, sm) {
	var form_heading_label=obj.text();
	var control='<div class="requf_tit form_control form_heading" id="form_heading_label" >'+form_heading_label+'</div>';
	return control;
}