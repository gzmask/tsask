function formTextArea(obj, sm) {
	var form_text_area_label=obj.text();
	var control='<div class="requ_desc form_control form_text_area" id="form_text_area_label" >'+form_text_area_label+'</div>';
	return control;	
}