<?php 
 phpinfo();
?>
