  <div class="header">
    <div class="icon_logo"><a href="#" title="technical safety authority interface design"><img src="/images/icon_logo.jpg" alt="technical safety authority interface design"/></a></div>
    <div class="icon_exit"><a href="<?php echo url_for('@sf_guard_signout');?>" title="logOut">log Out</a></div>
  </div>
