<div class="subnav">
<a href="<?php echo url_for('forms/new')?>" title="new form" class="newform">New Form</a>
<a href="<?php echo url_for('sfGuardUser/new')?>" title="new user" class="newuser">New User</a>
</div>