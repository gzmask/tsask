<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fct_tab">
  <tr>
    <th>User information</th>
    </tr>
</table>