<?php

/**
 * saOrders filter form.
 *
 * @package    authority
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class saOrdersFormFilter extends BasesaOrdersFormFilter
{
  public function configure()
  {
  }
}
