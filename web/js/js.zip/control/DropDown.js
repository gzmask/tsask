function addDropDown(obj, sm) {
var c=$('.fbc_list').append(
'    <li class="control_drop_down">'+
'    <div class="fbc_bar">'+
'    <div class="bar_tit">Drop Down</div>'+
'    <div class="bar_btns"><span>'+
'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
'    <a href="#!" title="DELETE" class="btn_del"></a>'+
'    </span></div>'+
'    </div>'+
'    <div class="fbc_txt">'+
'    <div class="fbct_half">'+
'      <input class="intxt inhalf" id="drop_down_text" value="Click to edit this text..." onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}"/>'+
'      </div>'+
'    <div class="hoptions">'+
'     <input name="searchdomain" type="hidden" value="">'+
'     <input id="headSearchType" name="searchType" type="hidden" value="playlist">'+
'     <div class="selSearch">'+
'    <div class="nowSearch" id="headSlected" onclick="if(document.getElementById(\'headSel\').style.display==\'none\'){document.getElementById(\'headSel\').style.display=\'block\';}else {document.getElementById(\'headSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'head\');"></div>'+
'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'headSel\').style.display==\'none\'){document.getElementById(\'headSel\').style.display=\'block\';}else {document.getElementById(\'headSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'head\');"></a></div>'+
'    <div class="clear"></div>'+
'    <ul class="selOption" id="headSel" style="display:none;">'+
'    <li><a href="#" onclick="return search_show(\'head\',\'sn\',this)" onmouseover="drop_mouseover(\'head\');" onmouseout="drop_mouseout(\'head\');">Username</a></li>'+
'    </ul>'+
'     </div>'+
'   </div>'+
'    <div class="btn_options">'+
'    <a href="#!" title="Options" id="op1" onclick="layshow(\'op1\'); return false" class="btn_ops">Options</a>'+
'    <div class="layoutbox" id="cont_op1">'+
'    <div class="laym">'+
'    <table width="100%" border="0" cellspacing="0" cellpadding="0">'+
'  <tr>'+
'    <td width="380">'+
'        <label>'+
'          <input class="intxt inhalf" value="Option1"/></label>'+
'   </td>'+
'    <td><img src="../images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input class="intxt inhalf" value="Option2"/>'+
'        </label>'+
'   </td>'+
'    <td><img src="../images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input class="intxt inhalf" value="Option3"/>'+
'        </label>'+
'   </td>'+
'    <td><img src="../images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'  <td>&nbsp;</td>'+
'  <td><img src="../images/icon_imgjia.jpg" alt="" title="add"/></td>'+
'  </tr>'+
'  <tr>'+
'  <td colspan="2">'+
'  <a href="#!" title="ok" class="btn_ok" onclick="layhide(\'op1\');return false">OK</a>'+
'  </td>'+
'  </tr>'+
'</table>'+
'    </div>'+
'    <div class="layb"></div>'+
'    </div>'+
'    </div>   '+
'    </div>'+
'    </li>');
bind_action(c);
};

function saveDropDown(obj, sm) {
	var drop_down_text=obj.find("#drop_down_text").val();
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="120">'+drop_down_text+'</th>';
	control=control+'    <td colspan="3"><div class="countrys">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="cardtpSearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="cardtpSlected" onclick="if(document.getElementById(\'cardtpSel\').style.display==\'none\'){document.getElementById(\'cardtpSel\').style.display=\'block\';}else {document.getElementById(\'cardtpSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'cardtp\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'cardtpSel\').style.display==\'none\'){document.getElementById(\'cardtpSel\').style.display=\'block\';}else {document.getElementById(\'cardtpSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'cardtp\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="cardtpSel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'cardtp\',\'cn\',this)" onmouseover="drop_mouseover(\'cardtp\');" onmouseout="drop_mouseout(\'cardtp\');">Contryname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}

function makeDropDown(obj, sm) {
	var drop_down_text=obj.find("#drop_down_text").val();
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="120">'+drop_down_text+'</th>';
	control=control+'    <td colspan="3"><div class="countrys">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="cardtpSearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="cardtpSlected" onclick="if(document.getElementById(\'cardtpSel\').style.display==\'none\'){document.getElementById(\'cardtpSel\').style.display=\'block\';}else {document.getElementById(\'cardtpSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'cardtp\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'cardtpSel\').style.display==\'none\'){document.getElementById(\'cardtpSel\').style.display=\'block\';}else {document.getElementById(\'cardtpSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'cardtp\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="cardtpSel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'cardtp\',\'cn\',this)" onmouseover="drop_mouseover(\'cardtp\');" onmouseout="drop_mouseout(\'cardtp\');">Contryname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}