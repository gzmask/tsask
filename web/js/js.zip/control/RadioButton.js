function addRadioButton(obj, sm) {
var c=$('.fbc_list').append(
'    <li class="control_radio_button">'+
'    <div class="fbc_bar">'+
'    <div class="bar_tit">Radio Button</div>'+
'    <div class="bar_btns"><span>'+
'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
'    <a href="#!" title="DELETE" class="btn_del"></a>'+
'    </span></div>'+
'    </div>'+
'    <div class="fbc_txt">'+
'    <div class="fbct_half">'+
'      <input class="intxt inhalf" value="Click to edit this text..." onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}"/>'+
'      </div>'+
'    <div class="oplist">'+
'    <table width="100%" border="0" cellspacing="0" cellpadding="0">'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input type="radio" name="RadioGroup1" value="��ѡ" id="RadioGroup1_0" />'+
'          <input class="intxt inhalf" value="Option1"/></label>'+
'   </td>'+
'    <td><img src="/images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input type="radio" name="RadioGroup1" value="��ѡ" id="RadioGroup1_1" />'+
'          <input class="intxt inhalf" value="Option2"/>'+
'        </label>'+
'   </td>'+
'    <td><img src="/images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input type="radio" name="RadioGroup1" value="��ѡ" id="RadioGroup1_1" />'+
'          <input class="intxt inhalf" value="Option3"/>'+
'        </label>'+
'   </td>'+
'    <td><img src="/images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'  <td>&nbsp;</td>'+
'  <td><img src="/images/icon_imgjia.jpg" alt="" title="add"/></td>'+
'  </tr>'+
'</table>'+
'    </div>'+
'    </div>'+
'    </li>');
bind_action(c);
};

function saveRadioButton(obj, sm) {
	var control='';
	return control;
}

function makeRadioButton(obj, sm) {
	var control='';
	return control;
}