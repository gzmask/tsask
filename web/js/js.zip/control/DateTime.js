function controlDateTime(str_date_time_text='Click to edit this text...',str_month_value='1',str_day_value='1',str_year_value='2012',str_hour_value='00',str_minutes_value='00') {
	var control_date_time='    <li class="control_date_time">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">DateTime</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'      <tr>'+
	'        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'          <tr>'+
	'            <td width="108" valign="top"><input class="intxt" id="date_time_text" value="'+str_date_time_text+'" onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}" style="width:100px;"/></td>'+
	'            <td width="46" align="left" valign="top"><input class="intxt" id="month_value" value="'+str_month_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />'+
	'<span class="fonti">Month</span></td>'+
	'            <td width="10" align="left" valign="middle"><span class="fontc2">/</span><br />'+
	'<span class="fonti">&nbsp;</span></td>'+
	'            <td width="46" align="left" valign="top"><input class="intxt" id="day_value" value="'+str_day_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />'+
	'<span class="fonti">Day</span></td>'+
	'            <td width="10" align="left" valign="middle"><span class="fontc2">/</span><br />'+
	'<span class="fonti">&nbsp;</span></td>'+
	'            <td width="46" align="left" valign="top"><input class="intxt" id="year_value" value="'+str_year_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />'+
	'<span class="fonti">Year</span></td>'+
	'            <td width="18" align="left" valign="middle"><span class="fontc2">at</span><br />'+
	'<span class="fonti">&nbsp;</span></td>'+
	'            <td width="46" align="left" valign="top"><input class="intxt" id="hour_value" value="'+str_hour_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />'+
	'<span class="fonti">Hour</span></td>'+
	'            <td width="10" align="left" valign="middle"><span class="fontc2">:</span><br />'+
	'<span class="fonti">&nbsp;</span></td>'+
	'            <td width="46" align="left" valign="top"><input class="intxt" id="minutes_value" value="'+str_minutes_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />'+
	'<span class="fonti">Minutes</span></td>'+
	'            <td width="97" align="left" valign="top"><div class="hoptions op_dtime">'+
	'     <input name="searchdomain" type="hidden" value="">'+
	'     <input id="dtimeSearchType" name="searchType" type="hidden" value="playlist">'+
	'     <div class="selSearch">'+
	'    <div class="nowSearch" id="dtimeSlected" onclick="if(document.getElementById(\'dtimeSel\').style.display==\'none\'){document.getElementById(\'dtimeSel\').style.display=\'block\';}else {document.getElementById(\'dtimeSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'dtime\');">AM</div>'+
	'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'dtimeSel\').style.display==\'none\'){document.getElementById(\'dtimeSel\').style.display=\'block\';}else {document.getElementById(\'dtimeSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'dtime\');"></a></div>'+
	'    <div class="clear"></div>'+
	'    <ul class="selOption" id="dtimeSel" style="display:none;">'+
	'    <li><a href="#" onclick="return search_show(\'dtime\',\'SW\',this)" onmouseover="drop_mouseover(\'dtime\');" onmouseout="drop_mouseout(\'dtime\');">AM</a></li>'+
	'    <li><a href="#" onclick="return search_show(\'dtime\',\'XW\',this)" onmouseover="drop_mouseover(\'dtime\');" onmouseout="drop_mouseout(\'dtime\');">PM</a></li>'+
	'    </ul>'+
	'     </div>'+
	'   </div></td>'+
	'            <td align="left" valign="middle"><img src="../images/icon_datetime.jpg" width="17" height="20" /><br />'+
	'<span class="fonti">&nbsp;</span></td>'+
	'          </tr>'+
	'        </table></td>'+
	'      </tr>'+
	'      </table>'+
	'    </div>'+
	'    </li>';
	return control_date_time;
}

function addDateTime(obj, sm) {
	var currentDate = new Date();
	var cMonth=currentDate.getMonth()+1;
	var cDay=currentDate.getDate();
	var cYear=currentDate.getFullYear();
	var cHour=currentDate.getHours();
	var cMinutes=currentDate.getMinutes()
	var c=$('.fbc_list').append(controlDateTime('Click to edit this text...',cMonth,cDay,cYear,cHour,cMinutes));
	bind_action(c);
};

function saveDateTime(obj, sm) {
	var date_time_text=obj.find("#date_time_text").val();
	var month_value=obj.find("#month_value").val();
	var day_value=obj.find("#day_value").val();
	var year_value=obj.find("#year_value").val();
	var hour_value=obj.find("#hour_value").val();		
	var minutes_value=obj.find("#minutes_value").val();		
	var control='';
	control=controlDateTime(date_time_text,month_value,day_value,year_value,hour_value,minutes_value);	
	return control;
}

function makeDateTime(obj, sm) {
	var date_time_text=obj.find("#date_time_text").val();
	var month_value=obj.find("#month_value").val();
	var day_value=obj.find("#day_value").val();
	var year_value=obj.find("#year_value").val();
	var hour_value=obj.find("#hour_value").val();		
	var minutes_value=obj.find("#minutes_value").val();	
	var control='';
	control=control+'      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'      <tr>';
	control=control+'        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'          <tr>';
	control=control+'            <td width="108" valign="top">'+date_time_text+'</td>';
	control=control+'            <td width="46" align="left" valign="top"><input class="intxt" id="month_value" value="'+month_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />';
	control=control+'<span class="fonti">Month</span></td>';
	control=control+'            <td width="10" align="left" valign="middle"><span class="fontc2">/</span><br />';
	control=control+'<span class="fonti">&nbsp;</span></td>';
	control=control+'            <td width="46" align="left" valign="top"><input class="intxt" id="day_value" value="'+day_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />';
	control=control+'<span class="fonti">Day</span></td>';
	control=control+'            <td width="10" align="left" valign="middle"><span class="fontc2">/</span><br />';
	control=control+'<span class="fonti">&nbsp;</span></td>';
	control=control+'            <td width="46" align="left" valign="top"><input class="intxt" id="year_value" value="'+year_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />';
	control=control+'<span class="fonti">Year</span></td>';
	control=control+'            <td width="18" align="left" valign="middle"><span class="fontc2">at</span><br />';
	control=control+'<span class="fonti">&nbsp;</span></td>';
	control=control+'            <td width="46" align="left" valign="top"><input class="intxt" id="hour_value" value="'+hour_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />';
	control=control+'<span class="fonti">Hour</span></td>';
	control=control+'            <td width="10" align="left" valign="middle"><span class="fontc2">:</span><br />';
	control=control+'<span class="fonti">&nbsp;</span></td>';
	control=control+'            <td width="46" align="left" valign="top"><input class="intxt" id="minutes_value" value="'+minutes_value+'" style="width:30px;" onfocus="if(value ==\'16\'){value =\'\'}" onblur="if (value ==\'\'){value=\'16\'}"/><br />';
	control=control+'<span class="fonti">Minutes</span></td>';
	control=control+'            <td width="97" align="left" valign="top"><div class="hoptions op_dtime">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="dtimeSearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="dtimeSlected" onclick="if(document.getElementById(\'dtimeSel\').style.display==\'none\'){document.getElementById(\'dtimeSel\').style.display=\'block\';}else {document.getElementById(\'dtimeSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'dtime\');">AM</div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'dtimeSel\').style.display==\'none\'){document.getElementById(\'dtimeSel\').style.display=\'block\';}else {document.getElementById(\'dtimeSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'dtime\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="dtimeSel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'dtime\',\'SW\',this)" onmouseover="drop_mouseover(\'dtime\');" onmouseout="drop_mouseout(\'dtime\');">AM</a></li>';
	control=control+'    <li><a href="#" onclick="return search_show(\'dtime\',\'XW\',this)" onmouseover="drop_mouseover(\'dtime\');" onmouseout="drop_mouseout(\'dtime\');">PM</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div></td>';
	control=control+'            <td align="left" valign="middle"><img src="../images/icon_datetime.jpg" width="17" height="20" /><br />';
	control=control+'<span class="fonti">&nbsp;</span></td>';
	control=control+'          </tr>';
	control=control+'        </table></td>';
	control=control+'      </tr>';
	control=control+'      </table>';
	return control;
}