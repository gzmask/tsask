function controlSubmitButton() {
	var control_submit_button='    <li class="control_submit_button">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Submit Button</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <div class="submittxt"><span>Submit</span></div>'+
	'    <div class="btn_options"> <a href="#!" title="Options" id="op2" onclick="layshow(\'op2\'); return false" class="btn_ops">Options</a>'+
	'      <div class="layoutbox" id="cont_op2">'+
	'        <div class="laym">'+
	'          <table width="100%" border="0" cellspacing="0" cellpadding="0">'+
	'            <tr>'+
	'              <td width="50%" valign="top"><input class="intxt inhalf" value="Option1"/>'+
	'                <br />'+
	'                <span class="fonti">Submit Text</span></td>'+
	'              <td valign="top"><div class="subtxt">'+
	'                <input name="searchdomain2" type="hidden" value="" />'+
	'                <input id="subtxtSearchType" name="subtxtSearchType" type="hidden" value="playlist" />'+
	'                <div class="selSearch">'+
	'                  <div class="nowSearch" id="subtxtSlected" onclick="if(document.getElementById(\'subtxtSel\').style.display==\'none\'){document.getElementById(\'subtxtSel\').style.display=\'block\';}else {document.getElementById(\'subtxtSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'subtxt\');">fdsafdsa</div>'+
	'                  <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'subtxtSel\').style.display==\'none\'){document.getElementById(\'subtxtSel\').style.display=\'block\';}else {document.getElementById(\'subtxtSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'subtxt\');"></a></div>'+
	'                  <div class="clear"></div>'+
	'                  <ul class="selOption" id="subtxtSel" style="display:none;">'+
	'                    <li><a href="#" onclick="return search_show(\'subtxt\',\'sn\',this)" onmouseover="drop_mouseover(\'subtxt\');" onmouseout="drop_mouseout(\'subtxt\');">Username</a></li>'+
	'                  </ul>'+
	'                </div>'+
	'              </div>'+
	'                <span class="fonti">Button Align</span></td>'+
	'            </tr>'+
	'            <tr>'+
	'              <td colspan="2"><a href="#!" title="ok" class="btn_ok" onclick="layhide(\'op2\');return false">OK</a></td>'+
	'            </tr>'+
	'          </table>'+
	'        </div>'+
	'        <div class="layb"></div>'+
	'      </div>'+
	'    </div>'+
	'    </div>'+
	'    </li>';
	return control_submit_button;
}

function addSubmitButton(obj, sm) {
	var c=$('.fbc_list').append(controlSubmitButton());
	bind_action(c);
};

function saveSubmitButton(obj, sm) {
	var control='';
	control=controlSubmitButton();	
	return control;
}

function makeSubmitButton(obj, sm) {
	var control='';
	control=control+'<div class="resubmit">';
	control=control+'<a href="#!" title="submit"><img src="/images/btn_submit.jpg" /></a>';
	control=control+'</div>';	
	return control;
}