function controlTextBox(str_text_box_text='Click to edit this text...'){
	var control_text_box='    <li class="control_text_box">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Text Box</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	''+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <input class="intxt" id="text_box_text" value="'+str_text_box_text+'" onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}"/>'+
	'    </div>'+
	'    </li>';
	return control_text_box;
}

function addTextBox(obj, sm) {
	var c=$('.fbc_list').append(controlTextBox());
	bind_action(c);
};

function saveTextBox(obj, sm) {
	var text_box_text=obj.find("#text_box_text").val();
	var control='';
	control=controlTextBox(text_box_text);
	return control;	
}

function makeTextBox(obj, sm) {
	var text_box_text=obj.find("#text_box_text").val();
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="120">'+text_box_text+'</th>';
	control=control+'    <td colspan="3"><input class="intxt" value="" style="width:500px;"/></td>';
	control=control+'  </tr>';
	control=control+'</table>';
	return control;	
}