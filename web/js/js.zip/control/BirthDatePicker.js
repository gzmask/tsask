function controlBirthDatePicker(str_birth_date_picker_text='Birth Date') {
	var control_birth_date_picker='    <li class="control_birth_date_picker">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Birth Date Picker</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'  <tr>'+
	'    <td width="98" valign="top"><input id="birth_date_picker_text" class="intxt" value="'+str_birth_date_picker_text+'" style="width:80px;"/></td>'+
	'    <td width="222" align="left" valign="top">'+
	'    <div class="hoptions op_month">'+
	'     <input name="searchdomain" type="hidden" value="">'+
	'     <input id="monthSearchType" name="searchType" type="hidden" value="playlist">'+
	'     <div class="selSearch">'+
	'    <div class="nowSearch" id="monthSlected" onclick="if(document.getElementById(\'monthSel\').style.display==\'none\'){document.getElementById(\'monthSel\').style.display=\'block\';}else {document.getElementById(\'monthSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'month\');"></div>'+
	'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'monthSel\').style.display==\'none\'){document.getElementById(\'monthSel\').style.display=\'block\';}else {document.getElementById(\'monthSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'month\');"></a></div>'+
	'    <div class="clear"></div>'+
	'    <ul class="selOption" id="monthSel" style="display:none;">'+
	'    <li><a href="#" onclick="return search_show(\'month\',\'cn\',this)" onmouseover="drop_mouseover(\'month\');" onmouseout="drop_mouseout(\'month\');">Monthname</a></li>'+
	'    </ul>'+
	'     </div>'+
	'   </div>'+
	'    <br />'+
	'<span class="fonti">Month</span></td>'+
	'    <td width="136" align="left" valign="middle">'+
	'    <div class="hoptions op_day">'+
	'     <input name="searchdomain" type="hidden" value="">'+
	'     <input id="daySearchType" name="searchType" type="hidden" value="playlist">'+
	'     <div class="selSearch">'+
	'    <div class="nowSearch" id="daySlected" onclick="if(document.getElementById(\'daySel\').style.display==\'none\'){document.getElementById(\'daySel\').style.display=\'block\';}else {document.getElementById(\'daySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'day\');"></div>'+
	'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'daySel\').style.display==\'none\'){document.getElementById(\'daySel\').style.display=\'block\';}else {document.getElementById(\'daySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'day\');"></a></div>'+
	'    <div class="clear"></div>'+
	'    <ul class="selOption" id="daySel" style="display:none;">'+
	'    <li><a href="#" onclick="return search_show(\'day\',\'cn\',this)" onmouseover="drop_mouseover(\'day\');" onmouseout="drop_mouseout(\'day\');">Dayname</a></li>'+
	'    </ul>'+
	'     </div>'+
	'   </div>'+
	'   <br />'+
	'<span class="fonti">Day</span></td>'+
	'    <td align="left" valign="top">'+
	'    <div class="hoptions op_year">'+
	'     <input name="searchdomain" type="hidden" value="">'+
	'     <input id="yearSearchType" name="searchType" type="hidden" value="playlist">'+
	'     <div class="selSearch">'+
	'    <div class="nowSearch" id="yearSlected" onclick="if(document.getElementById(\'yearSel\').style.display==\'none\'){document.getElementById(\'yearSel\').style.display=\'block\';}else {document.getElementById(\'yearSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'year\');"></div>'+
	'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'yearSel\').style.display==\'none\'){document.getElementById(\'yearSel\').style.display=\'block\';}else {document.getElementById(\'yearSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'year\');"></a></div>'+
	'    <div class="clear"></div>'+
	'    <ul class="selOption" id="yearSel" style="display:none;">'+
	'    <li><a href="#" onclick="return search_show(\'year\',\'cn\',this)" onmouseover="drop_mouseover(\'year\');" onmouseout="drop_mouseout(\'year\');">Yearname</a></li>'+
	'    </ul>'+
	'     </div>'+
	'   </div>'+
	'    <br />'+
	'<span class="fonti">Year</span></td>'+
	'  </tr>'+
	'</table>'+
	'    </div>'+
	'    </li>';
	return control_birth_date_picker;
}

function addBirthDatePicker(obj, sm) {
	var c=$('.fbc_list').append(controlBirthDatePicker());
	bind_action(c);
};

function saveBirthDatePicker(obj, sm) {
	var title_text=obj.find("#birth_date_picker_text").val();
	var control='';
	control=controlBirthDatePicker(title_text);		
	return control;
}

function makeBirthDatePicker(obj, sm) {
	var title_text=obj.find("#birth_date_picker_text").val();
	if('Click to edit this text...'==title_text){
		title_text='';
	}
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="80" valign="top">'+title_text+'</th>';
	control=control+'    <td width="222" align="left" valign="top">';
	control=control+'    <div class="hoptions op_month">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="monthSearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="monthSlected" onclick="if(document.getElementById(\'monthSel\').style.display==\'none\'){document.getElementById(\'monthSel\').style.display=\'block\';}else {document.getElementById(\'monthSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'month\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'monthSel\').style.display==\'none\'){document.getElementById(\'monthSel\').style.display=\'block\';}else {document.getElementById(\'monthSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'month\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="monthSel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'month\',\'cn\',this)" onmouseover="drop_mouseover(\'month\');" onmouseout="drop_mouseout(\'month\');">Monthname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div>';
	control=control+'    <br />';
	control=control+'<span class="fonti">Month</span></td>';
	control=control+'    <td width="132" align="left" valign="middle">';
	control=control+'    <div class="hoptions op_day">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="daySearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="daySlected" onclick="if(document.getElementById(\'daySel\').style.display==\'none\'){document.getElementById(\'daySel\').style.display=\'block\';}else {document.getElementById(\'daySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'day\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'daySel\').style.display==\'none\'){document.getElementById(\'daySel\').style.display=\'block\';}else {document.getElementById(\'daySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'day\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="daySel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'day\',\'cn\',this)" onmouseover="drop_mouseover(\'day\');" onmouseout="drop_mouseout(\'day\');">Dayname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div>';
	control=control+'   <br />';
	control=control+'<span class="fonti">Day</span></td>';
	control=control+'    <td align="left" valign="top">';
	control=control+'    <div class="hoptions op_year">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="yearSearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="yearSlected" onclick="if(document.getElementById(\'yearSel\').style.display==\'none\'){document.getElementById(\'yearSel\').style.display=\'block\';}else {document.getElementById(\'yearSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'year\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'yearSel\').style.display==\'none\'){document.getElementById(\'yearSel\').style.display=\'block\';}else {document.getElementById(\'yearSel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'year\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="yearSel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'year\',\'cn\',this)" onmouseover="drop_mouseover(\'year\');" onmouseout="drop_mouseout(\'year\');">Yearname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div>';
	control=control+'    <br />';
	control=control+'<span class="fonti">Year</span></td>';
	control=control+'  </tr>';
	control=control+'</table>';		
	return control;
}