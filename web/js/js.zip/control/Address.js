function controlAddress(str_address_text='Address') {
	var control_address='    <li class="control_address">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Address</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'  <tr>'+
	'    <td width="98" valign="top"><input class="intxt" id="address_text" value="'+str_address_text+'" style="width:80px;"/></td>'+
	'    <td colspan="2" align="left" valign="top"><input class="intxt" value="" style="width:500px;" /><br />'+
	'<span class="fonti">Street Address</span></td>'+
	'  </tr>'+
	'  <tr>'+
	'    <td width="98" valign="top">&nbsp;</td>'+
	'    <td colspan="2" align="left" valign="top"><input class="intxt" value="" style="width:500px;" /><br />'+
	'<span class="fonti">Street Address Line2</span></td>'+
	'  </tr>'+
	'  <tr>'+
	'    <td width="98" valign="top">&nbsp;</td>'+
	'    <td width="251" align="left" valign="top"><input class="intxt" value="" style="width:235px;" /><br />'+
	'<span class="fonti">City</span></td>'+
	'    <td align="left" valign="top"><input class="intxt" value="" style="width:235px;" /><br />'+
	'<span class="fonti">State/Province</span></td>'+
	'  </tr>'+
	'  <tr>'+
	'    <td width="98" valign="top">&nbsp;</td>'+
	'    <td width="235" align="left" valign="top"><input class="intxt" value="" style="width:235px;" /><br />'+
	'<span class="fonti">Postal/Zip Code</span></td>'+
	'    <td align="left" valign="top"><div class="countrys">'+
	'     <input name="searchdomain" type="hidden" value="">'+
	'     <input id="countrySearchType" name="searchType" type="hidden" value="playlist">'+
	'     <div class="selSearch">'+
	'    <div class="nowSearch" id="countrySlected" onclick="if(document.getElementById(\'countrySel\').style.display==\'none\'){document.getElementById(\'countrySel\').style.display=\'block\';}else {document.getElementById(\'countrySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'country\');"></div>'+
	'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'countrySel\').style.display==\'none\'){document.getElementById(\'countrySel\').style.display=\'block\';}else {document.getElementById(\'countrySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'country\');"></a></div>'+
	'    <div class="clear"></div>'+
	'    <ul class="selOption" id="countrySel" style="display:none;">'+
	'    <li><a href="#" onclick="return search_show(\'country\',\'cn\',this)" onmouseover="drop_mouseover(\'country\');" onmouseout="drop_mouseout(\'country\');">Contryname</a></li>'+
	'    </ul>'+
	'     </div>'+
	'   </div><br />'+
	'<span class="fonti">Country</span></td>'+
	'  </tr>'+
	'</table>'+
	'    </div>'+
	'    </li>';
	return control_address;
}
function addAddress(obj, sm) {
	var c=$('.fbc_list').append(controlAddress());
	bind_action(c);
};

function saveAddress(obj, sm) {
	var title_text=obj.find("#address_text").val();
	var control='';
	control=controlAddress(title_text);	
	return control;
}

function makeAddress(obj, sm) {
	var title_text=obj.find("#address_text").val();
	if('Click to edit this text...'==title_text){
		title_text='';
	}
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="80" rowspan="4" valign="top">'+title_text+'</th>';
	control=control+'    <td colspan="2" align="left" valign="top"><input class="intxt" value="" style="width:500px;" /><br />';
	control=control+'<span class="fonti">Street Address</span></td>';
	control=control+'  </tr>';
	control=control+'  <tr>';
	control=control+'    <td colspan="2" align="left" valign="top"><input class="intxt" value="" style="width:500px;" /><br />';
	control=control+'  <span class="fonti">Street Address Line2</span></td>';
	control=control+'  </tr>';
	control=control+'  <tr>';
	control=control+'    <td width="251" align="left" valign="top"><input class="intxt" value="" style="width:235px;" /><br />';
	control=control+'  <span class="fonti">City</span></td>';
	control=control+'    <td align="left" valign="top"><input class="intxt" value="" style="width:238px;" />';
	control=control+'      <br />';
	control=control+'<span class="fonti">State/Province</span></td>';
	control=control+'  </tr>';
	control=control+'  <tr>';
	control=control+'    <td width="235" align="left" valign="top"><input class="intxt" value="" style="width:235px;" /><br />';
	control=control+'  <span class="fonti">Postal/Zip Code</span></td>';
	control=control+'    <td align="left" valign="top"><div class="countrys">';
	control=control+'     <input name="searchdomain" type="hidden" value="">';
	control=control+'     <input id="countrySearchType" name="searchType" type="hidden" value="playlist">';
	control=control+'     <div class="selSearch">';
	control=control+'    <div class="nowSearch" id="countrySlected" onclick="if(document.getElementById(\'countrySel\').style.display==\'none\'){document.getElementById(\'countrySel\').style.display=\'block\';}else {document.getElementById(\'countrySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'country\');"></div>';
	control=control+'    <div class="btnSel"><a href="#" onclick="if(document.getElementById(\'countrySel\').style.display==\'none\'){document.getElementById(\'countrySel\').style.display=\'block\';}else {document.getElementById(\'countrySel\').style.display=\'none\';};return false;" onmouseout="drop_mouseout(\'country\');"></a></div>';
	control=control+'    <div class="clear"></div>';
	control=control+'    <ul class="selOption" id="countrySel" style="display:none;">';
	control=control+'    <li><a href="#" onclick="return search_show(\'country\',\'cn\',this)" onmouseover="drop_mouseover(\'country\');" onmouseout="drop_mouseout(\'country\');">Contryname</a></li>';
	control=control+'    </ul>';
	control=control+'     </div>';
	control=control+'   </div><br />';
	control=control+'<span class="fonti">Country</span></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}