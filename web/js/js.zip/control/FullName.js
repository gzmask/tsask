function controlFullName(str_full_name_text='Full Name') {
	var control_full_name='    <li class="control_full_name">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Full Name</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'  <tr>'+
	'    <td width="98" valign="top"><input  id="full_name_text" class="intxt" value="'+str_full_name_text+'" style="width:80px;"/></td>'+
	'    <td width="251" align="left" valign="top"><input class="intxt" value="" style="width:235px;"/>'+
	'      <br />'+
	'      <span class="fonti">First Name</span></td>'+
	'    <td align="left" valign="top"><input class="intxt" value="" style="width:235px;"/>'+
	'     <br />'+
	'      <span class="fonti">Last Name</span></td>'+
	'  </tr>'+
	'</table>'+
	'    </div>'+
	'    </li>';
	return control_full_name;
}
function addFullName(obj, sm) {
	var c=$('.fbc_list').append(controlFullName());
	bind_action(c);
};

function saveFullName(obj, sm) {
	var title_text=obj.find("#full_name_text").val();
	var control='';
	control=controlFullName(title_text);	
	return control;
}

function makeFullName(obj, sm) {
	var title_text=obj.find("#full_name_text").val();
	if('Click to edit this text...'==title_text){
		title_text='';
	}
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'  <th width="80" valign="top">'+title_text+'</th>';
	control=control+'    <td width="251" align="left" valign="top"><input class="intxt" value="" style="width:235px;"/>';
	control=control+'      <br />';
	control=control+'      <span class="fonti">First Name</span></td>';
	control=control+'    <td align="left" valign="top"><input class="intxt" value="" style="width:238px;"/>';
	control=control+'     <br />';
	control=control+'      <span class="fonti">Last Name</span></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}