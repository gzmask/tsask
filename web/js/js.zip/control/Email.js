function controlEmail(str_email_text='E-mail') {
	var control_email='   <li class="control_email">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">E-mail</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'  <tr>'+
	'    <td width="98"><input class="intxt" id="email_text" value="'+str_email_text+'" style="width:80px;"/></td>'+
	'    <td align="left"><input class="intxt" value="" style="width:500px;"/></td>'+
	'  </tr>'+
	'</table>'+
	'    </div>'+
	'    </li>';
	return control_email;
}

function addEmail(obj, sm) {
	var c=$('.fbc_list').append(controlEmail());
	bind_action(c);
};

function saveEmail(obj, sm) {
	var title_text=obj.find("#email_text").val();
	var control='';
	control=controlEmail(title_text);	
	return control;
}

function makeEmail(obj, sm) {
	var title_text=obj.find("#email_text").val();
	if('Click to edit this text...'==title_text){
		title_text='';
	}
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <th width="80" valign="top">'+title_text+'</th>';
	control=control+'    <td colspan="2" align="left" valign="top"><input class="intxt" value="" style="width:500px;"/> </td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}