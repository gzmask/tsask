function controlPayment(str_payment_text='Click to edit this text...', str_cost_value='', str_tax_value='',str_shipping_value='', str_extra_value='Click to edit this text...') {
	var control_payment='    <li class="control_payment">'+
	'    <div class="fbc_bar">'+
	'    <div class="bar_tit">Payment</div>'+
	'    <div class="bar_btns"><span>'+
	'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
	'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
	'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
	'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
	'    <a href="#!" title="DELETE" class="btn_del"></a>'+
	'    </span></div>'+
	'    </div>'+
	'    <div class="fbc_txt">'+
	'    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">'+
	'  <tr>'+
	'    <td width="118" valign="top"><input class="intxt" id="payment_text" value="'+str_payment_text+'" onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}" style="width:100px;"/></td>'+
	'    <td width="98" align="left" valign="top"><input class="intxt" id="cost_value" value="'+str_cost_value+'"  style="width:80px;"/><br /><span class="fonti">Cost</span></td>'+
	'    <td width="98" align="left" valign="top"><input class="intxt" id="tax_value" value="'+str_tax_value+'"  style="width:80px;"/><br /><span class="fonti">Tax(%)</span></td>'+
	'    <td width="98" align="left" valign="top"><input class="intxt" id="shipping_value" value="'+str_shipping_value+'"  style="width:80px;"/><br /> <span class="fonti">Shipping</span></td>'+
	'    <td align="left" valign="top"><input class="intxt" id="extra_value" value="'+str_extra_value+'" onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}" style="width:200px;"/>'+
	'    <br />'+
	'    <span class="fonti">Extra field</span></td>'+
	'  </tr>'+
	'</table>'+
	'    </div>'+
	'    </li>';
	return control_payment;
}
function addPayment(obj, sm) {
	var c=$('.fbc_list').append(controlPayment());
	bind_action(c);
};

function savePayment(obj, sm) {
	var payment_text=obj.find("#payment_text").val();
	var cost_value=obj.find("#cost_value").val();	
	var tax_value=obj.find("#tax_value").val();
	var shipping_value=obj.find("#shipping_value").val();	
	var extra_value=obj.find("#extra_value").val();	
	var control='';
	control=controlPayment(payment_text,cost_value,tax_value,shipping_value,extra_value);
	return control;
}

function makePayment(obj, sm) {
	var payment_text=obj.find("#payment_text").val();
	var cost_value=obj.find("#cost_value").val();	
	var tax_value=obj.find("#tax_value").val();
	var shipping_value=obj.find("#shipping_value").val();	
	var extra_value=obj.find("#extra_value").val();	
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0" class="fulln_tab">';
	control=control+'  <tr>';
	control=control+'    <td width="118" valign="top">'+payment_text+'</td>';
	control=control+'    <td width="98" align="left" valign="top"><input class="intxt" id="cost_value" value="'+cost_value+'"  style="width:80px;" readonly="true" /><br /><span class="fonti">Cost</span></td>';
	control=control+'    <td width="98" align="left" valign="top"><input class="intxt" id="tax_value" value="'+tax_value+'"  style="width:80px;" readonly="true" /><br /><span class="fonti">Tax(%)</span></td>';
	control=control+'    <td width="98" align="left" valign="top"><input class="intxt" id="shipping_value" value="'+shipping_value+'"  style="width:80px;" readonly="true" /><br /> <span class="fonti">Shipping</span></td>';
	control=control+'    <td align="left" valign="top"><input class="intxt" id="extra_value" value="'+extra_value+'"  style="width:200px;" readonly="true" />';
	control=control+'    <br />';
	control=control+'    <span class="fonti">Extra field</span></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}