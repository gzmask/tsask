function addFileUpload(obj, sm) {
var c=$('.fbc_list').append(
'    <li class="control_file_upload">'+
'    <div class="fbc_bar">'+
'    <div class="bar_tit">File Upload</div>'+
'    <div class="bar_btns"><span>'+
'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
'    <a href="#!" title="DELETE" class="btn_del"></a>'+
'    </span></div>'+
'    </div>'+
'    <div class="fbc_txt">'+
'    <div class="fbct_half">'+
'      <input class="intxt inhalf" value="Click to edit this text..." onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}"/>'+
'      </div>'+
'    <div class="fileup"><input class="intxt inhalf" value="" name=""/></div>'+
'    <div class="btn_options">'+
'    <a href="#!" title="Browse" class="btn_ops">Browse</a>'+
'    </div>'+
'    </div>'+
'    </li>');
bind_action(c);
};

function saveFileUpload(obj, sm) {
	var control='';
	return control;
}

function makeFileUpload(obj, sm) {
	var control='';
	return control;
}