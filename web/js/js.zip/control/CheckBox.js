function addCheckBox(obj, sm) {
var c=$('.fbc_list').append(
'    <li class="control_check_box">'+
'    <div class="fbc_bar">'+
'    <div class="bar_tit">Check Box</div>'+
'    <div class="bar_btns"><span>'+
'    <a href="#!" title="ARROW DOWN" class="btn_down" ></a>'+
'    <a href="#!" title="ARROW UP" class="btn_up"></a>'+
'    <a href="#!" title="ARROW BOTTOM" class="btn_bottom"></a>'+
'    <a href="#!" title="ARROW TOP" class="btn_top"></a>'+
'    <a href="#!" title="DELETE" class="btn_del"></a>'+
'    </span></div>'+
'    </div>'+
'    <div class="fbc_txt">'+
'    <div class="fbct_half">'+
'      <input class="intxt inhalf" id="check_box_text" value="Click to edit this text..." onfocus="if(value ==\'Click to edit this text...\'){value =\'\'}" onblur="if (value ==\'\'){value=\'Click to edit this text...\'}"/>'+
'      </div>'+
'    <div class="oplist">'+
'    <table width="100%" border="0" cellspacing="0" cellpadding="0">'+
'  <tr>'+
'    <td>'+
'        <label>'+
'          <input type="checkbox" name="RadioGroup1" value="��ѡ" id="RadioGroup1_0" />'+
'          <input class="intxt inhalf" value="Option1"/></label>'+
'   </td>'+
'    <td><img src="/images/icon_imgjian.jpg" alt="" title="delete"/></td>'+
'  </tr>'+
'  <tr>'+
'  <td>&nbsp;</td>'+
'  <td><img src="/images/icon_imgjia.jpg" alt="" title="add"/></td>'+
'  </tr>'+
'</table>'+
'    </div>'+
'    </div>'+
'    </li>');
bind_action(c);
};

function saveCheckBox(obj, sm) {
	var check_box_text=obj.find("#check_box_text").val();
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	control=control+'  <tr>';
	control=control+'    <th width="70">'+check_box_text+'</th>';
	control=control+'    <td><label><input name="" type="checkbox" value="" />&nbsp;&nbsp;by checking this box, I hereby agree to the terms stated above.</label></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}

function makeCheckBox(obj, sm) {
	var check_box_text=obj.find("#check_box_text").val();
	var control='';
	control=control+'<table width="100%" border="0" cellspacing="0" cellpadding="0">';
	control=control+'  <tr>';
	control=control+'    <th width="70">'+check_box_text+'</th>';
	control=control+'    <td><label><input name="" type="checkbox" value="" />&nbsp;&nbsp;by checking this box, I hereby agree to the terms stated above.</label></td>';
	control=control+'  </tr>';
	control=control+'</table>';	
	return control;
}